import { Component } from '@angular/core';

@Component({
  selector: 'app-page-not-working',
  templateUrl: './page-not-working.component.html',
  styleUrls: ['./page-not-working.component.css']
})
export class PageNotWorkingComponent {

}
